//Raghavi's first repl program
//Lesson0-Ex:1
//Output your name
//console.log("Raghavi Srinivasan")

//Ex:2
//Read name of your user
var readlineSync=require("readline-sync");
//var userName=readlineSync.question("May I know your name? ");
//console.log("Nice name " +  userName);

//Ex:3
//welcome your user
//var welcomeMsg="Welcome " + userName;
//console.log(welcomeMsg);

//Ex:4:Do it all together
//Ex:5:
//Print right/wrong if greater than 25
//Ex:6
//Increment score if right answer
var score=0;
var questionOne="Is Bokaro your home town?"//here instead of directly loading string we stored it in a variable and passed that variable
var answerOne="no";
var userAnswerHomeTown=readlineSync.question(questionOne);
if(userAnswerHomeTown==answerOne){
  score=score+1;
  console.log("Score is:" + score);
}
else{
  score=score-1;
  console.log("Score is:" + score);
}

//Set 2:
var questionTwo="Am I older than 25? ";//here instead of directly loading string we stored it in a variable and passed that variable
var answerTwo="no";
var userAnswerAge=readlineSync.question(questionTwo);
if(userAnswerAge==answerTwo){
  score=score+1;
  console.log("Score is:" + score);
}
else{
  score=score-1;
  console.log("Score is:" + score);
}