
function add(numberOne,numberTwo){
  console.log("Number 1: ", + numberOne);
  console.log("Number 2: ", + numberTwo);
  var sum=numberOne + numberTwo;
  return sum;
}
//function calling
var result=add(2,3);
console.log("Sum is: ", + result)

//live homework
//function which returns product
function prod(numberOne,numberTwo){
  console.log("Number 1: ", + numberOne);
  console.log("Number 2: ", + numberTwo);
  var mul=numberOne * numberTwo;
  return mul;
}
//function calling
var result=prod(2,3);
console.log("Product is: ", + result)