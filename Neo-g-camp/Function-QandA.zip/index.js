
var readlineSync=require("readline-sync");
var score=0;

function play(question,answer){
  var userAnswer=readlineSync.question(question);

  if(userAnswer === answer){
    console.log("Yow were right!");
    score=score+1;
  }
  else{
    console.log("You were wrong!");
    score=score-1;
  }
}
//calling a function
play("Where do I study? ","SVCE");
play("Where do I live? ","Chennai");
console.log("Your score is: ", + score);